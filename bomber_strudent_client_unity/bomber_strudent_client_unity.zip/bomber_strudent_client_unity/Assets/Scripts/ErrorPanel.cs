using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ErrorPanel : MonoBehaviour
{
    private static ErrorPanel instance;

    public Text text;
    public string message;
    public GameObject panel;
    private bool isDisplayed;

    private void Awake()
    {
        if(instance != null)
        {
            GameObject.Destroy(this.gameObject);
        }
        else
        {
            instance = this;
        }

    }
    private void Update()
    {
        if (isDisplayed)
        {
            panel.SetActive(true);
            text.text = message;
        }
    }
    public static ErrorPanel getInstance()
    {
        return instance;
    }

    public void displayError(string error)
    {
        message = error;
        isDisplayed = true;
    }
    public void returnToMainMenu()
    {
        Destroy(NetworkManager.getInstance().gameObject);
        Destroy(PartieManager.getInstance().gameObject);
        SceneManager.LoadScene("menuScene");
    }

}
