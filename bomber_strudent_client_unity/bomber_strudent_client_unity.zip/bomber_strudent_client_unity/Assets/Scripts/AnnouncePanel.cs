using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AnnouncePanel : MonoBehaviour
{
    private string message;
    public Text text;
    public float readyDuration;
    public float goDuration;
    private float time;

    private void Update()
    {
        if (time <= 0)
        {
            text.text = "";
            //this.gameObject.SetActive(false);
        }
        else
        {
            text.text = message;
            time -= Time.deltaTime;
        }
    }
    public void setText( string message,float duration)
    {
        this.message = message;
        time = duration;
    }
    public void setReady(float readyTime)
    {
        setText("ready? " + readyTime + "s",readyDuration);
    }
    public void setGo()
    {
        setText("Go!", goDuration);
    }
}
