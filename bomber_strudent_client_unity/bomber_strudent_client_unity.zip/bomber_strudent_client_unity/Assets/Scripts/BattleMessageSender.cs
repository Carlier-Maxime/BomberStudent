using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BattleMessageSender : MonoBehaviour
{
    public PlayerManager playerManager;
    public PlayerState playerState;
    public BombManager bombManager;

    public void startGame()
    {
        string message = "POST game/start";
        NetworkManager.getInstance().sendTCPMessage(message);
    }
    public void activeRemotebomb()
    {
        string message = "POST attack/remote/go";
        NetworkManager.getInstance().sendTCPMessage(message);

    }
    public void Up()
    {
        string message = "POST player/move{\"dir\":\"up\"}";
        NetworkManager.getInstance().sendTCPMessage(message);
    }
    public void Down()
    {
        string message = "POST player/move{\"dir\":\"down\"}";
        NetworkManager.getInstance().sendTCPMessage(message);
    }
    public void Left()
    {
        string message = "POST player/move{\"dir\":\"left\"}";
        NetworkManager.getInstance().sendTCPMessage(message);
    }
    public void Right()
    {
        string message = "POST player/move{\"dir\":\"right\"}";
        NetworkManager.getInstance().sendTCPMessage(message);
    }

    public void PlaceBomb(BombType bombType)
    {
        string bombTypeString = bombType == BombType.classic ? "classic" : bombType == BombType.remote ? "remote" : "mine";
        Vector2Int coord = playerManager.getPlayer("...").getPos();
        bombManager.addPlayerBomb(new Bomb(coord, bombType));
        string message = "POST attack/bomb{\"type\":\""+bombTypeString+"\"}";


        NetworkManager.getInstance().sendTCPMessage(message);


        /*if (bombType == BombType.classic && playerState.getNbClassicBomb() > 0)
        {
            playerState.setNbClassicBomb(playerState.getNbClassicBomb() - 1);

            messageReceiver.placeBomb(bombType, player.getPos(), playerState);
        }
        else if (bombType == BombType.remote && playerState.getNbRemoteBomb() > 0)
        {
            playerState.setNbRemoteBomb(playerState.getNbRemoteBomb() - 1);

            messageReceiver.placeBomb(bombType, player.getPos(), playerState);
        }
        else if (bombType == BombType.mine && playerState.getNbMine() > 0)
        {
            playerState.setNbMine(playerState.getNbMine() - 1);

            messageReceiver.placeBomb(bombType, player.getPos(), playerState);
        }*/
    }
}
