

public enum BombType
{
    classic,
    remote,
    mine
    
}
