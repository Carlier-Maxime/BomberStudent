using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputManager : MonoBehaviour
{
   

    private BombType chosenBomb=BombType.classic;
    public BattleMessageSender messageSender;
    public BombCount bombCount;
    private bool gameStarted = false;
    private bool gameEnded = false;


    private void Awake()
    {
        if(this.messageSender != null)
        {
            Debug.Log("ok");
        }
        else
        {
            Debug.Log("ko");
        }
    }
    private void Update()
    {
        if (!gameEnded)
        {
            if (gameStarted)
            {
                getMove();
                getAction();
            }
            else
            {
                if (Input.GetKeyDown(KeyCode.Return) && PartieManager.getInstance().getIsPartieCreator())
                {
                    messageSender.startGame();
                }
            }
        }
    }
    public void startGame()
    {
        this.gameStarted = true;
    }
    private void getMove()
    {

        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            messageSender.Up();
        }
        else if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            messageSender.Down();

        }
        else if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            messageSender.Left();

        }
        else if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            messageSender.Right();

        }
    }
    public void end()
    {
        this.gameEnded = true;
    }

    private void getAction()
    {
        if (Input.GetKeyDown(KeyCode.Z))
        {
            messageSender.PlaceBomb(chosenBomb);

        }else if (Input.GetKeyDown(KeyCode.X))
        {
            messageSender.activeRemotebomb();
        }else if (Input.GetKeyDown(KeyCode.Tab))
        {
            chosenBomb = (BombType)((int)(chosenBomb + 1) %3);
            bombCount.selectBomb(chosenBomb);
            Debug.Log(chosenBomb.ToString());
        }
    }
}
