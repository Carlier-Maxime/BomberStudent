using System.Net;
using System.Net.Sockets;
using UnityEngine;
using System.Threading;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System;
public class NetworkManager : MonoBehaviour
{
    private static NetworkManager instance;
    private UdpClient udpClient;
    private UdpClient udpListener;

    private TcpClient tcpClient;
    private TcpListener tcpListener;
    public int port;
    public bool increaseSendingUDP;

    private bool isConnectedTCP = false;
    private bool isListeningUDP = false;

    private string targetIpAddress;

    public MessageParser messageParser;

    private void Awake()
    {
        if(NetworkManager.instance != null)
        {
            GameObject.Destroy(this.gameObject);
        }
        else
        {
            DontDestroyOnLoad(this);
            NetworkManager.instance = this;
        }

    }
    /*private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            sendTCPMessage("Bonjour\n");
        }
    }*/
    /*private void Start()
    {
        startListeningUDP(42069);
        initTCPClient("127.0.0.1", 42070);
        sendTCPMessage("Ok");
        initTCPListener(42069);
        startTCPListen();
    }*/

   

    public void startListeningUDP(int port)
    {
        if (!isListeningUDP && udpClient != null)
        {
            Debug.Log("ok");
            isListeningUDP = true;
            //this.udpListener = new UdpListener(port);
            Thread thread = new Thread(() => ListenUDP());
            thread.Start();
        }

        
    }

    private void ListenUDP()
    {
        Debug.Log("le port:" + port);
        IPEndPoint iPEndPoint = new IPEndPoint(IPAddress.Any, port + (increaseSendingUDP ? 1 : 0));
        while (isListeningUDP)
        {
            try
            {
                Debug.Log("ok1");
                byte[] data = this.udpListener.Receive(ref iPEndPoint);
                if (!isListeningUDP)
                {
                    this.udpListener.Close();
                    this.udpListener.Dispose();
                    return;
                }
                Debug.Log("ok2");
                string message = System.Text.Encoding.ASCII.GetString(data, 0, data.Length);
                Debug.Log(message);
                messageParser.parseMessage(message, iPEndPoint.Address);
            } catch(SocketException e)
            {
                isListeningUDP = false;
            }

        }
    }
    public void stopListeningUDP()
    {
        this.isListeningUDP = false;
        this.udpClient.Close();
        this.udpClient.Dispose();
    }
    public void initUpdClient(string addressIP)
    {
        this.udpClient = new UdpClient();
        udpClient.Connect(addressIP, port + (increaseSendingUDP? 1:0));
        udpClient.EnableBroadcast = true;
        Debug.Log(((IPEndPoint)this.udpClient.Client.LocalEndPoint).Port.ToString());
        this.udpListener = new UdpClient((IPEndPoint) this.udpClient.Client.LocalEndPoint);
        
    }
    public static NetworkManager getInstance()
    {
        return instance;
    }

    public void sendUDPMessage(string message)
    {
        
        message += "$"  ;
        byte[] packetData = System.Text.Encoding.ASCII.GetBytes(message);

        /*IPEndPoint endPoint = new IPEndPoint(IPAddress.Parse(addressIP),port);
        Socket client = new Socket(AddressFamily.InterNetwork, SocketType.Dgram,ProtocolType.Udp);
        client.SendTo(packetData, endPoint);*/

        udpClient.Send(packetData, packetData.Length);

    }

    public IPEndPoint initTCPClient(string ipAdress, int port)
    {
        this.tcpClient = new TcpClient(ipAdress, port);
        return (IPEndPoint)tcpClient.Client.LocalEndPoint;
    }
    public void startTCP()
    {
        connectTCP(targetIpAddress, port, port);
    }
    public void stoptTCP()
    {
        this.isConnectedTCP = false;
        if (tcpClient != null)
        {
            this.tcpClient.Close();
            this.tcpClient.Dispose();
        }
        if (tcpListener != null)
        {
            this.tcpListener.Stop();
        }

    }

    public void sendTCPMessage(string message)
    {

        message += "$";
        byte[] packetData = System.Text.Encoding.ASCII.GetBytes(message);
        for(int i = 0; i < message.Length; i++)
        {
            Debug.Log(message.ToCharArray()[i]);
            Debug.Log("["+i+"] "+message.Length);
        }
        if (tcpClient.Connected)
        {
            NetworkStream stream = this.tcpClient.GetStream();
            try
            {
                stream.Write(packetData,0,packetData.Length);
            }
            catch (IOException e)
            {
                Debug.Log("Fin de connexion inattendue");
                
                ErrorPanel.getInstance().displayError("send: fin de connexion innatendu " + e.ToString());

            }
        }
    }
    public void connectTCP(string ipAddress, int sendingPort, int listeningPort)
    {
        isConnectedTCP = true;
       // this.tcpListener = new TcpListener()
        IPEndPoint ep = initTCPClient(ipAddress, sendingPort + (increaseSendingUDP ? 1 : 0));
        initTCPListener(ep);
        startTCPListen();
    }
    public void initTCPListener(IPEndPoint ep)//int port)
    {
        //IPAddress localAddr = IPAddress.Parse("127.0.0.1");
        //this.tcpListener = new TcpListener(ep);

    }

    private void startTCPListen()
    {
            Thread thread = new Thread(() => TCPListen());
            thread.Start();

    }
    private void TCPListen()
    {
        Debug.Log("ok listen");
        byte[] bytes = new byte[2048];
        string data = null;
        //tcpListener.Start();
        Debug.Log("Waiting for a connection... ");

        using TcpClient client = this.tcpClient;//tcpListener.AcceptTcpClient();

        Debug.Log("Connected!");

        data = null;

        NetworkStream stream = client.GetStream();

        int i;
        try
        {
            while ((i = stream.Read(bytes, 0, bytes.Length)) != 0)
            {
                data = System.Text.Encoding.ASCII.GetString(bytes, 0, i);
                Debug.Log("Received: " + data+"("+i+")");
                MessageParser.getInstance().parseMessage(data,IPAddress.Any);

            }
        }
        catch (IOException e)
        {
            Debug.Log("Fin de connexion inattendue");

            ErrorPanel.getInstance().displayError("listen: fin de connexion innatendu " + e.ToString());
        }

    }

    public void setTargetIpAddress(string ipAddress)
    {
        this.targetIpAddress = ipAddress;
    }

    

}

