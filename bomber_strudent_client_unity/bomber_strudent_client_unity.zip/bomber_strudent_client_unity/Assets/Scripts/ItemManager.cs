using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemManager : MonoBehaviour
{

    public MapGenerator mapGenerator;

    public List<Item> nextItems= new List<Item>();

    private bool changed = false;

    private void Update()
    {
        if (changed)
        {
            changed = false;
            //updateItem();
        }
    }
}
