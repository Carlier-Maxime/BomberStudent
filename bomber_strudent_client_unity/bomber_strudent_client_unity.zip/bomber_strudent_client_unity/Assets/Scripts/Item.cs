using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour
{
    private Vector2Int coord;
    private ItemType type;

    private bool obtained = false;

    private void Update()
    {
        if (obtained)
        {
            GameObject.Destroy(this);
        }
    }

    public void hasBeenObtained()
    {
        obtained = true;
    }
    public void setType(ItemType type)
    {
        this.type = type;
    }
    public void setCoord(Vector2Int coord, MapGenerator mapGenerator){
        this.coord = coord;
        this.gameObject.transform.position = mapGenerator.getPosForCoord(coord);
    }
    public Vector2Int getCoord()
    {
        return this.coord;
    }
    public ItemType getType()
    {
        return this.type;
    }
}
